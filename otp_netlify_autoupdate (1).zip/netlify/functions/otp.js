const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
const cheerio = require('cheerio');

// Reads cookies from environment variables set in Netlify
const XSRF = process.env.XSRF_TOKEN || '';
const LARAVEL = process.env.LARAVEL_SESSION || '';
const EXTRA = process.env.EXTRA_COOKIE || ''; // e.g., BKhWIi8bk...

exports.handler = async function(event, context) {
  if (!XSRF || !LARAVEL) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Missing env vars: XSRF_TOKEN, LARAVEL_SESSION (+ EXTRA_COOKIE optional)' }),
      headers: { 'content-type': 'application/json' }
    };
  }

  try {
    const res = await fetch('https://lamanche.money/notify/cards/3d-codes', {
      headers: {
        'user-agent': 'Mozilla/5.0',
        'accept-language': 'ru',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'upgrade-insecure-requests': '1',
        'referer': 'https://lamanche.money/',
        'cookie': `XSRF-TOKEN=${XSRF}; laravel_session=${LARAVEL}; ${EXTRA ? 'BKhWIi8bkJWPDvgxciRQl5bbZyFMmpDvuJENFix7=' + EXTRA + ';' : ''}`
      },
      method: 'GET'
    });

    if (!res.ok) {
      return { statusCode: res.status, body: JSON.stringify({ error: 'Upstream HTTP ' + res.status }), headers: { 'content-type': 'application/json' } };
    }

    const html = await res.text();
    const $ = cheerio.load(html);
    const now = new Date();
    const rows = [];

    $('tr').each((_, tr) => {
      const tds = $(tr).find('td');
      if (tds.length >= 7) {
        const date = $(tds[0]).text().trim();
        const user = $(tds[1]).text().trim();
        const amount = $(tds[2]).text().trim();
        const card = $(tds[3]).text().trim();
        const otp = $(tds[4]).text().trim();
        const merchant = $(tds[5]).text().trim();
        const type = $(tds[6]).text().trim();

        // Filter: keep only last 1 hour
        // date expected format: DD.MM.YYYY HH:MM
        const [d, m, yTime] = date.split('.');
        if (!yTime) return;
        const [y, hm] = yTime.split(' ');
        if (!hm) return;
        const [hh, mm] = hm.split(':');
        const dt = new Date(Number(y), Number(m)-1, Number(d), Number(hh), Number(mm));
        const diffMs = now - dt;
        if (diffMs >= 0 && diffMs <= 60*60*1000) {
          rows.push({ date, user, amount, card, otp, merchant, type });
        }
      }
    });

    return {
      statusCode: 200,
      body: JSON.stringify(rows),
      headers: { 'content-type': 'application/json', 'cache-control': 'no-store' }
    };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }), headers: { 'content-type': 'application/json' } };
  }
};
